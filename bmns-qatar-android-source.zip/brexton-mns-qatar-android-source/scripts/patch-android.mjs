import fs from 'node:fs';
const path = 'android/app/src/main/AndroidManifest.xml';
if (!fs.existsSync(path)) throw new Error(`Missing ${path}; run npx cap add android first.`);
let xml = fs.readFileSync(path, 'utf8');
xml = xml.replace(/<activity([^>]*android:name="\\.MainActivity"[^>]*)>/, (match, attrs) => {
  const updated = attrs.includes('android:launchMode=') ? attrs : `${attrs} android:launchMode="singleTask"`;
  return `<activity${updated}>`;
});
const intent = `
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="brextonqatar" android:host="auth" android:pathPrefix="/callback" />
            </intent-filter>`;
xml = xml.replace(/(<activity[^>]*android:name="\\.MainActivity"[^>]*>)/, `$1${intent}`);
fs.writeFileSync(path, xml);
