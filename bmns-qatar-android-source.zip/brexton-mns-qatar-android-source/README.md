# BMnS Qatar Android wrapper

This is a fresh Capacitor 7 Android wrapper for the existing hosted portal:
https://brexton-mns-qatar.hatchable.site

## Build
1. Push this project to the GitHub repository.
2. Run Actions → BMnS Qatar Android APK → Run workflow.
3. Download the `brexton-mns-qatar-android-apk` artifact.

## Authentication return-to-app: important integration step
The Android project registers this callback:
`brextonqatar://auth/callback`

The hosted website's authentication provider/server must use that exact redirect URI after successful login, and the web app must handle the callback and restore its session. Merely registering an Android intent filter cannot force an OAuth provider or the website to redirect to the app. The current hosted site source and provider configuration are not included in this wrapper ZIP, so this server-side/web-side callback step remains to be connected and tested.

For OAuth, use Authorization Code + PKCE, validate `state`, and do not place client secrets in the Android app. Do not store passwords or long-lived provider secrets in local storage.

## Firebase
No Firebase project credentials or service-account private keys are included. Configure Firebase for Android separately and add the client `google-services.json` as a protected build input only after confirming the Firebase project/package ID is `com.brextonmns.qatar`. Never commit an Admin SDK service-account JSON file.
