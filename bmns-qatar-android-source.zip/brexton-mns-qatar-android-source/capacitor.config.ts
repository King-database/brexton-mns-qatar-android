import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.brextonmns.qatar',
  appName: 'BMnS Qatar',
  webDir: 'www',
  server: {
    // The production portal remains hosted on Hatchable.
    url: 'https://brexton-mns-qatar.hatchable.site',
    cleartext: false,
    allowNavigation: [
      'brexton-mns-qatar.hatchable.site'
    ]
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1800,
      backgroundColor: '#040D27',
      showSpinner: false,
      androidScaleType: 'CENTER_CROP'
    }
  }
};

export default config;
