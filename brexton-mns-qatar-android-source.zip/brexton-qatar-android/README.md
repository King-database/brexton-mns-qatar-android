# BREXTON MnS Qatar — Android APK wrapper

This is a Capacitor Android wrapper for the existing Hatchable website. It uses the current hosted application and its existing authentication/database; it does not create a second backend.

## Important deployment prerequisite

The Hatchable project is currently set to **Personal/private**. Before customers can use the Android app, change the project's visibility to **Public** in Hatchable Console → project Settings. Otherwise visitors may see Hatchable's platform sign-in wall before reaching the app's own login.

Project: https://hatchable.com/console/projects/brexton-mns-qatar  
Website: https://brexton-mns-qatar.hatchable.site

## Build the APK with GitHub Actions

This source package includes a cloud build workflow, so Android Studio and the Android SDK are not required on your phone.

1. Download and extract this ZIP.
2. Create a new GitHub repository named `brexton-qatar-android`.
3. Upload the extracted files to the repository's `main` branch.
4. Open the repository's **Actions** tab.
5. Select **Build BREXTON Qatar Android APK** and tap **Run workflow** (or wait for the first push build).
6. When the workflow finishes, open the run and download the artifact named `brexton-mns-qatar-debug-apk`.
7. Extract the artifact and install `app-debug.apk` on Android. If prompted, allow Chrome/Files to install unknown apps.

## Current build type

The workflow creates a **debug APK** for first-device testing and direct sideload installation. It is not a Play Store release. For reliable in-place customer updates, create a persistent signing key and configure a signed release build before wider distribution; do not distribute successive debug builds as production updates.

## App behavior and limitations

- App ID: `com.brextonmns.qatar`
- App name: BREXTON MnS Qatar
- Brand colors: maroon `#8a1538`, navy `#071b35`
- Loads `https://brexton-mns-qatar.hatchable.site`
- Requires internet for live records and server-side actions.
- Uses the existing Hatchable login and backend.
- This initial wrapper is a WebView-based hosted app, not a fully native offline application.
- External domains are not intended to be embedded; links to other sites may open outside the app depending on the website/browser behavior.

## Security

Do not add API secrets, Hatchable owner credentials, or private signing keys to this repository. Configure production signing secrets in GitHub Actions Secrets only.
