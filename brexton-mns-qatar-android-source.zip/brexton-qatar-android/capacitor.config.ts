import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.brextonmns.qatar',
  appName: 'BREXTON MnS Qatar',
  webDir: 'www',
  server: {
    // The app loads the existing Hatchable service; it does not create a second database.
    url: 'https://brexton-mns-qatar.hatchable.site',
    cleartext: false,
    allowNavigation: ['brexton-mns-qatar.hatchable.site']
  },
  android: {
    allowMixedContent: false,
    captureInput: true
  }
};

export default config;
