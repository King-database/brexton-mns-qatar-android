# BREXTON MnS Qatar — Android wrapper update

## What changed
- Updated Capacitor navigation allowlist to include the BREXTON Hatchable host and Hatchable subdomains only. This is intended to keep Hatchable redirects inside the WebView without opening every website inside the app.
- Replaced the launcher icon with the new BREXTON navy/electric-blue/cyan identity.
- Rebuilt the splash artwork to match the icon and changed placeholder branding from Qatar maroon to BREXTON blue.
- Added Capacitor 7 Push Notifications and Splash Screen packages.
- Added Firebase Android client configuration and Google Services Gradle setup to the build workflow.
- Kept the existing Hatchable site as the only application backend.

## Build
Upload the contents of this folder to the existing GitHub repository's `main` branch, replacing the old files. The workflow builds a debug APK under Actions → Build BREXTON Qatar Android APK.

## Push notifications: remaining app-side connection
The Hatchable server endpoints already deployed are:
- `POST /api/push/devices` to register the signed-in device token
- `DELETE /api/push/devices` to unregister it
- `GET /api/notifications` to retrieve notification history and unread count
- `PUT /api/notifications` to mark notifications read

The native plugin is included in this Android build. The Hatchable frontend still needs to call the Capacitor Push Notifications plugin after login, request Android notification permission, send the returned FCM token to `POST /api/push/devices`, and handle notification taps. That frontend code cannot be injected into the hosted Hatchable site by this wrapper ZIP alone; it must be added to the Hatchable frontend. Notification event triggers also need to be connected to relevant business actions.

## Firebase configuration
`google-services.json` is the Android client configuration and is included. Do not put the Firebase Admin service-account private key in this repository. Keep `FIREBASE_SERVICE_ACCOUNT_JSON` only in Hatchable's protected secret settings.

## Testing the Chrome issue
After installing the new APK, verify:
1. The app opens from its icon and remains in the app after the initial redirect.
2. Sign-in, dashboard navigation, quotation and invoice pages remain inside the app.
3. An external link to an unrelated website opens outside the app as expected.
4. Android Back navigates within the app before exiting.

If Chrome still opens, record the final URL shown in Chrome. That will identify the redirect host that needs a specific in-app navigation rule. The source ZIP did not include a native `MainActivity` override, so a custom native navigation handler may still be required if the site explicitly launches an external intent or uses `window.open()`.
