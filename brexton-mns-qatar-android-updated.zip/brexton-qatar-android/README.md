# BREXTON MnS Qatar — Android wrapper

Capacitor 7 Android shell for the existing Hatchable application. The app continues to use `https://brexton-mns-qatar.hatchable.site` and its existing database/backend.

## Build with GitHub Actions
1. Upload the contents of this folder to the existing repository `King-database/brexton-mns-qatar-android`, replacing the old files.
2. Open GitHub → Actions → **Build BREXTON Qatar Android APK**.
3. Run the workflow and wait for it to finish.
4. Download the `brexton-mns-qatar-debug-apk` artifact and install the APK on Android.

## Navigation
The Capacitor WebView is configured to keep the BREXTON Hatchable hostname and Hatchable subdomains in-app. Other domains remain external. This addresses the likely allowlist/redirect cause, but must be verified on the phone because the hosted site may explicitly launch Chrome with a new-window or external-intent link.

## Notifications
The Capacitor Push Notifications plugin and Firebase Android client config are included. The Hatchable backend notification endpoints were deployed separately. The Hatchable frontend still needs to register the FCM token after login and handle notification taps; see `ANDROID-UPDATE-NOTES.md`.

## Security
The included `google-services.json` is Firebase Android client configuration. Never add the Firebase Admin service-account private key to this repository. Keep `FIREBASE_SERVICE_ACCOUNT_JSON` only in Hatchable's protected secret settings.

## Current build
GitHub Actions builds a debug APK for device testing. A signed release build with a protected signing key is required before Play Store/customer distribution.
