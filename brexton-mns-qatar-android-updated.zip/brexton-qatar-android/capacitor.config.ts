import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.brextonmns.qatar',
  appName: 'BREXTON MnS Qatar',
  webDir: 'www',
  server: {
    // Keep the existing Hatchable application and its database as the only backend.
    url: 'https://brexton-mns-qatar.hatchable.site',
    cleartext: false,
    // Hatchable may redirect between its app host and managed subdomains.
    // Keep those routes in the embedded WebView; do not allow every domain.
    allowNavigation: [
      'brexton-mns-qatar.hatchable.site',
      '*.hatchable.site'
    ]
  },
  android: {
    allowMixedContent: false,
    captureInput: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 1800,
      backgroundColor: '#040D27',
      showSpinner: false
    },
    PushNotifications: {
      presentationOptions: ['badge', 'sound', 'alert']
    }
  }
};

export default config;
